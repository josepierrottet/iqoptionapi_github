import time
from iqoptionapi.stable_api import IQ_Option
import time
import numpy as np
import pandas as pd
import concurrent.futures
import threading
from datetime import datetime
from datetime import timedelta
trade_log = []
username = "my-email"
password = "my-password"
api = IQ_Option(username, password)


def main():
    operador_binarias()
    #save_binary_history_to_txt()
    #trade_digital("EURJPY-OTC")
    #trade("EURJPY")
    #imprimir_activos_binarios()
    #imprimir_activos_digital()
    #operador_digitales()  
    #pruebita()

def pruebita():
    expiration_time = 60
    api.buy_digital_spot("EURJPY-OTC",1, "call", 5)
    symbols2 = ["EURGBP-OTC","EURUSD-OTC""GBPUSD-OTC"]
   


def convert_milliseconds_to_datetime(milliseconds):
    # Convertir milisegundos a segundos
    seconds = milliseconds / 1000
    # Crear un objeto datetime a partir de los segundos desde la época Unix
    dt = datetime.fromtimestamp(seconds)
    # Devolver la representación de cadena de fecha y hora del objeto datetime
    return dt.strftime("%Y-%m-%d %H:%M:%S")



def save_binary_history_to_txt():
    limit = 10
    offset = 0
    start = int((time.time() - 86400))
    end = int(time.time())

    success, position_history_v2 = api.get_position_history_v2("turbo-option", limit, offset, start, end)
    if success:
        print("Guardando historial de posiciones en opciones binarias (últimas 24 horas) en historial.txt...")
        print("Positions:", position_history_v2["positions"])
        with open("historial.txt", "a") as f:
            for position in position_history_v2["positions"]:
                open_time_str = convert_milliseconds_to_datetime(position['open_time'])
                close_time_str = convert_milliseconds_to_datetime(position['close_time'])
                f.write(f"Source: {position['source']},ID: {position['id']}, Open Time: {open_time_str}, Invest: {position['invest']}, Close Reason: {position['close_reason']}, Close Time: {close_time_str}, Reason: {signal_reasons.get(position[position])}\n")                    
        print("Historial de posiciones guardado exitosamente en historial.txt")
    else:
        print("Error al obtener el historial de posiciones en opciones binarias (últimas 24 horas)")







def write_signal_reason(reason):
    with open("razon.txt", "a") as f:
        f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())} - {reason}\n")



def bollinger_bands(data, period, multiplier):
    sma = data.rolling(window=period).mean()
    std_dev = data.rolling(window=period).std()
    upper_band = sma + (std_dev * multiplier)
    lower_band = sma - (std_dev * multiplier)
    return upper_band, lower_band




def get_candles_with_reconnect(api, *args, **kwargs):
    
    max_retries = 5
    retries = 0
    while retries < max_retries:
        candles = api.get_candles(*args, **kwargs)
        if candles is not None:
            return candles
        else:
            print("Error fetching candles, reconnecting...")
            api.connect()
            retries += 1
            time.sleep(2)
    return None



def imprimir_activos_binarios():
    

    api = IQ_Option("jose.pierrottet@udla.edu.ec", "0984220903jA")

    if api.connect():
        print("Conexión exitosa")
    else:
        print("Error en la conexión")

    all_assets = api.get_all_open_time()["digital"]
    binaries = [asset for asset in all_assets if all_assets[asset]["open"]]

    # Fetch all active opcodes
    actives_opcodes = api.get_all_ACTIVES_OPCODE()

    for binary in binaries:
        # Find the opcode with the matching symbol
        opcode = None
        for symbol, code in actives_opcodes.items():
            if symbol == binary:
                opcode = code
                break

        if opcode is not None:
            print(f"{binary} (ID: {opcode})")
        else:
            print(f"{binary} (ID not found)")

        time.sleep(0.1)


def imprimir_activos_digital():
    print ("hola")
    api = IQ_Option("jose.pierrottet@udla.edu.ec", "0984220903jA")

    if api.connect():
        print("Conexión exitosa")
    else:
        print("Error en la conexión")

    all_assets = api.get_all_open_time()["turbo"]
    digital_options = [asset for asset in all_assets if all_assets[asset]["open"]]
    
    # Fetch all active opcodes
    actives_opcodes = api.get_all_ACTIVES_OPCODE()

    for digital_option in digital_options:
        # Find the opcode with the matching symbol
        opcode = None
        for symbol, code in actives_opcodes.items():
            if symbol == digital_option:
                opcode = code
                break

        if opcode is not None:
            print(f"{digital_option} (ID: {opcode})")
        else:
            print(f"{digital_option} (ID not found)")

        time.sleep(0.1)










def ichimoku(data):
    high_prices = data['max']
    low_prices = data['min']
    close_prices = data['close']

    tenkan_sen = (high_prices.rolling(9).max() + low_prices.rolling(9).min()) / 2
    kijun_sen = (high_prices.rolling(26).max() + low_prices.rolling(26).min()) / 2
    senkou_span_a = ((tenkan_sen + kijun_sen) / 2).shift(26)
    senkou_span_b = ((high_prices.rolling(52).max() + low_prices.rolling(52).min()) / 2).shift(26)
    chikou_span = close_prices.shift(-26)

    return {
        "tenkan_sen": tenkan_sen,
        "kijun_sen": kijun_sen,
        "senkou_span_a": senkou_span_a,
        "senkou_span_b": senkou_span_b,
        "chikou_span": chikou_span
    }


def ema(data, period):
    
    return data.ewm(span=period).mean()

def rsi(data, period):
    delta = data.diff().dropna()
    gains = delta.where(delta > 0, 0)
    losses = -delta.where(delta < 0, 0)
    avg_gain = gains.ewm(com=period - 1, min_periods=period).mean()
    avg_loss = losses.ewm(com=period - 1, min_periods=period).mean()
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))



print("Conexión exitosa" if api.connect() else "Error en la conexión")
account_type = "REAL"  # Change to "REAL" for real account
api.change_balance(account_type)
amount=api.get_balance() * 0.15 #dinero a invertir
 




#symbol = "EURUSD-OTC"
timeframe = "M1"
ema_short_period = 26
ema_long_period = 52
rsi_period = 14
rsi_buy_threshold = 30
rsi_sell_threshold = 70
signal_line_period = 16
macd_signal_diff_min = 0.0002

def macd(data, short_period=ema_short_period, long_period=ema_long_period, signal_period=signal_line_period):
    ema_short = ema(data, short_period)
    ema_long = ema(data, long_period)
    macd_line = ema_short - ema_long
    signal_line = ema(macd_line, signal_period)
    return macd_line, signal_line







def trade_binarias(symbol):
    
    initial_balance = api.get_balance()
    
    
    
    
    upper_balance_limit = initial_balance * 1.29
    lower_balance_limit = initial_balance * 0.7
    
    

    while True:
        
        
        current_balance = api.get_balance()
        if current_balance >= upper_balance_limit:
            print("Ganancia alcanzada. Deteniendo el programa.")
            print(f"Ganancia total: {current_balance - initial_balance}")
            break
        elif current_balance <= lower_balance_limit:
            print("Pérdida alcanzada. Deteniendo el programa.")
            print(f"Pérdida total: {initial_balance - current_balance}")
            break

        
        price_history = get_candles_with_reconnect(api, symbol, 60, 100, time.time())
        if len(price_history) < 100:
            print("Not enough data to proceed. Waiting for more data...")
            time.sleep(60)
            continue
        
        data = pd.DataFrame(price_history).drop_duplicates(subset=["from"])
        data.index = pd.to_datetime(data["from"], unit="s")


        
        # Get Ichimoku components
        ichimoku_components = ichimoku(data)
        data["tenkan_sen"] = ichimoku_components["tenkan_sen"]
        data["kijun_sen"] = ichimoku_components["kijun_sen"]
        data["senkou_span_a"] = ichimoku_components["senkou_span_a"]
        data["senkou_span_b"] = ichimoku_components["senkou_span_b"]
        data["chikou_span"] = ichimoku_components["chikou_span"]
        
        


        # EMA and RSI calculations
        data["ema_short"] = ema(data["close"], ema_short_period)
        data["ema_long"] = ema(data["close"], ema_long_period)
        data["rsi"] = rsi(data["close"], rsi_period)

        # Bollinger Bands parameters
        bb_period = 28
        bb_multiplier = 3

        # Calculate Bollinger Bands
        data["upper_band"], data["lower_band"] = bollinger_bands(data["close"], bb_period, bb_multiplier)


        # Calculate MACD and Signal lines
        data["macd"], data["signal"] = macd(data["close"])

        # Generate buy signals using EMA crossover, RSI, Bollinger Bands, and MACD crossover
        buy_signal_ema_rsi = (data["ema_short"].iloc[-1] > data["ema_long"].iloc[-1]) and (data["rsi"].iloc[-1] < rsi_buy_threshold)
        buy_signal_bb = (
        data["close"].iloc[-1] < data["lower_band"].iloc[-1] and
        data["close"].iloc[-2] > data["lower_band"].iloc[-2]
        )
        
        buy_signal_macd = data["macd"].iloc[-1] > data["signal"].iloc[-1] and data["macd"].iloc[-2] <= data["signal"].iloc[-2] and abs(data["macd"].iloc[-1] - data["signal"].iloc[-1]) >= macd_signal_diff_min

        buy_signal_ichimoku = (
        data["tenkan_sen"].iloc[-1] > data["kijun_sen"].iloc[-1] and
        data["close"].iloc[-1] > data["senkou_span_a"].iloc[-1] and
        data["close"].iloc[-1] > data["senkou_span_b"].iloc[-1] and
        data["chikou_span"].iloc[-1] > data["close"].iloc[-1] and
        all(data["close"].iloc[-2:-4:-1] > data["senkou_span_a"].iloc[-2:-4:-1]) and
        all(data["close"].iloc[-2:-4:-1] > data["senkou_span_b"].iloc[-2:-4:-1])
        )
        


        
        buy_signal = buy_signal_ema_rsi | buy_signal_bb  | buy_signal_ichimoku #| buy_signal_macd

        # Generate sell signals using EMA crossover, RSI, Bollinger Bands, and MACD crossover
        sell_signal_ema_rsi = (data["ema_short"].iloc[-1] < data["ema_long"].iloc[-1]) and (data["rsi"].iloc[-1] > rsi_sell_threshold)
        sell_signal_bb = (
        data["close"].iloc[-1] > data["upper_band"].iloc[-1] and
        data["close"].iloc[-2] < data["upper_band"].iloc[-2]
        )
        sell_signal_macd = data["macd"].iloc[-1] < data["signal"].iloc[-1] and data["macd"].iloc[-2] >= data["signal"].iloc[-2] and abs(data["macd"].iloc[-1] - data["signal"].iloc[-1]) >= macd_signal_diff_min

        sell_signal_ichimoku = (
        data["tenkan_sen"].iloc[-1] < data["kijun_sen"].iloc[-1] and
        data["close"].iloc[-1] < data["senkou_span_a"].iloc[-1] and
        data["close"].iloc[-1] < data["senkou_span_b"].iloc[-1] and
        data["chikou_span"].iloc[-1] < data["close"].iloc[-1] and
        all(data["close"].iloc[-2:-4:-1] < data["senkou_span_a"].iloc[-2:-4:-1]) and
        all(data["close"].iloc[-2:-4:-1] < data["senkou_span_b"].iloc[-2:-4:-1])
        )
        
        sell_signal = sell_signal_ema_rsi | sell_signal_bb   | sell_signal_ichimoku #| sell_signal_macd
        
        if buy_signal:
            
            if buy_signal_ema_rsi:
                write_signal_reason(f"{symbol}: Buy signal (EMA crossover & RSI < {rsi_buy_threshold})")
            if buy_signal_bb:
                write_signal_reason(f"{symbol}: Buy signal (Price below Bollinger Bands lower band)")
            if buy_signal_macd:
                write_signal_reason(f"{symbol}: Buy signal (MACD crossover)")
            if buy_signal_ichimoku:
                write_signal_reason(f"{symbol}: Buy signal (ICHIMOKU)")
            
            
            
            
            print(f"{symbol}: Señal de compra")
            check, buy_order_id = api.buy(amount, symbol, "call", 2)
            print(f"Buy order ID: {buy_order_id}")
            print("Verificando resultado...")
            result = api.check_win_v3(buy_order_id) 
            if result > 0:
                print(f"Ganancia: {result}")
            elif result == 0:
                print("Empate")
            else:
                print(f"Perdida: {result}")
            

        if sell_signal:
            
            if sell_signal_ema_rsi:
                write_signal_reason(f"{symbol}: Sell signal (EMA crossover & RSI > {rsi_sell_threshold})")
            if sell_signal_bb:
                write_signal_reason(f"{symbol}: Sell signal (Price above Bollinger Bands upper band)")
            if sell_signal_macd:
                write_signal_reason(f"{symbol}: Sell signal (MACD crossover)")
            if sell_signal_ichimoku:
                write_signal_reason(f"{symbol}: Sell signal (ICHIMOKU)")
            
            print(f"{symbol}: Señal de venta")
            check, sell_order_id = api.buy(amount, symbol, "put", 2)
            print(f"Sell order ID: {sell_order_id}")
            print("Verificando resultado...")
            result = api.check_win_v3(sell_order_id)
            
            if result > 0:
                print(f"Ganancia: {result}")
            elif result == 0:
                print("Empate")
            else:
                print(f"Perdida: {result}")
            

        
        time.sleep(3)



def trade_digital(symbol):
    
    print("Conexión exitosa" if api.connect() else "Error en la conexión")
    amount=api.get_balance() * 0.06 #dinero a invertir
    account_type = "REAL"  # Change to "REAL" for real account
    api.change_balance(account_type) 
    global initial_balance
    upper_balance_limit = initial_balance * 1.13
    lower_balance_limit = initial_balance * 0.80
    
    
    
    # Set the expiration time for the digital option (e.g., 60 seconds)
    expiration_time = 5

    while True:
        print("escuchando")
        
        current_balance = api.get_balance()
        if current_balance >= upper_balance_limit:
            print("Ganancia alcanzada. Deteniendo el programa.")
            print(f"Ganancia total: {current_balance - initial_balance}")
            break
        elif current_balance <= lower_balance_limit:
            print("Pérdida alcanzada. Deteniendo el programa.")
            print(f"Pérdida total: {initial_balance - current_balance}")
            break

        
        price_history = get_candles_with_reconnect(api, symbol, 60, 100, time.time())
        if len(price_history) < 100:
            print("Not enough data to proceed. Waiting for more data...")
            time.sleep(60)
            continue
        
        data = pd.DataFrame(price_history).drop_duplicates(subset=["from"])
        data.index = pd.to_datetime(data["from"], unit="s")


        
        # Get Ichimoku components
        ichimoku_components = ichimoku(data)
        data["tenkan_sen"] = ichimoku_components["tenkan_sen"]
        data["kijun_sen"] = ichimoku_components["kijun_sen"]
        data["senkou_span_a"] = ichimoku_components["senkou_span_a"]
        data["senkou_span_b"] = ichimoku_components["senkou_span_b"]
        data["chikou_span"] = ichimoku_components["chikou_span"]
        
        


        # EMA and RSI calculations
        data["ema_short"] = ema(data["close"], ema_short_period)
        data["ema_long"] = ema(data["close"], ema_long_period)
        data["rsi"] = rsi(data["close"], rsi_period)

        # Bollinger Bands parameters
        bb_period = 28
        bb_multiplier = 3

        # Calculate Bollinger Bands
        data["upper_band"], data["lower_band"] = bollinger_bands(data["close"], bb_period, bb_multiplier)


        # Calculate MACD and Signal lines
        data["macd"], data["signal"] = macd(data["close"])

        # Generate buy signals using EMA crossover, RSI, Bollinger Bands, and MACD crossover
        buy_signal_ema_rsi = (data["ema_short"].iloc[-1] > data["ema_long"].iloc[-1]) and (data["rsi"].iloc[-1] < rsi_buy_threshold)
        buy_signal_bb = (
        data["close"].iloc[-1] < data["lower_band"].iloc[-1] and
        data["close"].iloc[-2] > data["lower_band"].iloc[-2]
        )
        
        buy_signal_macd = data["macd"].iloc[-1] > data["signal"].iloc[-1] and data["macd"].iloc[-2] <= data["signal"].iloc[-2] and abs(data["macd"].iloc[-1] - data["signal"].iloc[-1]) >= macd_signal_diff_min

        buy_signal_ichimoku = (
        data["tenkan_sen"].iloc[-1] > data["kijun_sen"].iloc[-1] and
        data["close"].iloc[-1] > data["senkou_span_a"].iloc[-1] and
        data["close"].iloc[-1] > data["senkou_span_b"].iloc[-1] and
        data["chikou_span"].iloc[-1] > data["close"].iloc[-1] and
        all(data["close"].iloc[-2:-4:-1] > data["senkou_span_a"].iloc[-2:-4:-1]) and
        all(data["close"].iloc[-2:-4:-1] > data["senkou_span_b"].iloc[-2:-4:-1])
        )
        


        
        buy_signal =  buy_signal_bb  | buy_signal_ichimoku #| buy_signal_macd | buy_signal_ema_rsi 

        # Generate sell signals using EMA crossover, RSI, Bollinger Bands, and MACD crossover
        sell_signal_ema_rsi = (data["ema_short"].iloc[-1] < data["ema_long"].iloc[-1]) and (data["rsi"].iloc[-1] > rsi_sell_threshold)
        sell_signal_bb = (
        data["close"].iloc[-1] > data["upper_band"].iloc[-1] and
        data["close"].iloc[-2] < data["upper_band"].iloc[-2]
        )
        sell_signal_macd = data["macd"].iloc[-1] < data["signal"].iloc[-1] and data["macd"].iloc[-2] >= data["signal"].iloc[-2] and abs(data["macd"].iloc[-1] - data["signal"].iloc[-1]) >= macd_signal_diff_min

        sell_signal_ichimoku = (
        data["tenkan_sen"].iloc[-1] < data["kijun_sen"].iloc[-1] and
        data["close"].iloc[-1] < data["senkou_span_a"].iloc[-1] and
        data["close"].iloc[-1] < data["senkou_span_b"].iloc[-1] and
        data["chikou_span"].iloc[-1] < data["close"].iloc[-1] and
        all(data["close"].iloc[-2:-4:-1] < data["senkou_span_a"].iloc[-2:-4:-1]) and
        all(data["close"].iloc[-2:-4:-1] < data["senkou_span_b"].iloc[-2:-4:-1])
        )
        
        sell_signal = sell_signal_bb   | sell_signal_ichimoku #| sell_signal_macd |  sell_signal_ema_rsi 
        
        if buy_signal:
            
            if buy_signal_ema_rsi:
                write_signal_reason(f"{symbol}: Buy signal (EMA crossover & RSI < {rsi_buy_threshold})")
            if buy_signal_bb:
                write_signal_reason(f"{symbol}: Buy signal (Price below Bollinger Bands lower band)")
            if buy_signal_macd:
                write_signal_reason(f"{symbol}: Buy signal (MACD crossover)")
            if buy_signal_ichimoku:
                write_signal_reason(f"{symbol}: Buy signal (ICHIMOKU)")
            
            
            
            
            print(f"{symbol}: Señal de compra")
            buy_order_id = api.buy_digital_spot(symbol,amount, "call", expiration_time)
            

            print(f"Buy order ID: {buy_order_id}")
            print("Verificando resultado...")
            result = api.check_win_digital_v2(buy_order_id) 
            if result > 0:
                print(f"Ganancia: {result}")
            elif result == 0:
                print("Empate")
            else:
                print(f"Perdida: {result}")
            

        if sell_signal:
            
            if sell_signal_ema_rsi:
                write_signal_reason(f"{symbol}: Sell signal (EMA crossover & RSI > {rsi_sell_threshold})")
            if sell_signal_bb:
                write_signal_reason(f"{symbol}: Sell signal (Price above Bollinger Bands upper band)")
            if sell_signal_macd:
                write_signal_reason(f"{symbol}: Sell signal (MACD crossover)")
            if sell_signal_ichimoku:
                write_signal_reason(f"{symbol}: Sell signal (ICHIMOKU)")
            
            print(f"{symbol}: Señal de venta")
            check, sell_order_id = api.buy_digital_spot(symbol,amount, "put", expiration_time)

            print(f"Sell order ID: {sell_order_id}")
            print("Verificando resultado...")
            result = api.check_win_digital_v2(sell_order_id)
            
            if result > 0:
                print(f"Ganancia: {result}")
            elif result == 0:
                print("Empate")
            else:
                print(f"Perdida: {result}")
            

        
        time.sleep(3)





def operador_binarias():

    

    # Define your three symbols
    symbols = ["EURJPY","EURGBP","EURUSD"]
    symbols1 = ["EURJPY-OTC","EURGBP-OTC","EURUSD-OTC"]
    symbols2 = ["EURJPY-OTC","EURGBP-OTC","EURUSD-OTC","GBPJPY-OTC","GBPUSD-OTC"]
    symbols3 = ["EURGBP","EURUSD"]

    # Run the trading logic for each symbol in parallel
    with concurrent.futures.ThreadPoolExecutor() as executor:
        executor.map(trade_binarias, symbols3)
    
def operador_digitales():

    

    # Define your three symbols
    symbols = ["EURJPY","EURGBP","EURUSD"]
    symbols1 = ["EURJPY-OTC","EURGBP-OTC","EURUSD-OTC"]
    symbols2 = ["EURJPY-OTC","EURGBP-OTC","EURUSD-OTC","GBPJPY-OTC","GBPUSD-OTC"]
    symbols3 = ["EURGBP-OTC","EURUSD-OTC","GBPUSD-OTC"]

    # Run the trading logic for each symbol in parallel
    with concurrent.futures.ThreadPoolExecutor() as executor:
        executor.map(trade_digital, symbols3)


if __name__ == "__main__":
  main()

 
